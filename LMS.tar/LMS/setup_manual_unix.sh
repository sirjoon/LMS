#!/bin/bash
# LMS Manual Setup Script for macOS/Linux
# This script sets up LMS without Docker using local services

set -e

echo "🚀 Setting up LMS manually on Unix system..."
echo "============================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}$1${NC}"
}

print_warning() {
    echo -e "${YELLOW}$1${NC}"
}

print_error() {
    echo -e "${RED}$1${NC}"
}

print_info() {
    echo -e "${CYAN}$1${NC}"
}

# Check prerequisites
check_prerequisites() {
    print_warning "🔍 Checking prerequisites..."
    
    local missing_prereqs=()
    
    if ! command -v python3 &> /dev/null; then
        missing_prereqs+=("Python 3.11+ (https://python.org/downloads/)")
    fi
    
    if ! command -v node &> /dev/null; then
        missing_prereqs+=("Node.js 18+ (https://nodejs.org/)")
    fi
    
    if ! command -v psql &> /dev/null; then
        missing_prereqs+=("PostgreSQL 14+ - Install with: brew install postgresql (macOS) or sudo apt install postgresql (Linux)")
    fi
    
    if ! command -v redis-cli &> /dev/null; then
        missing_prereqs+=("Redis - Install with: brew install redis (macOS) or sudo apt install redis-server (Linux)")
    fi
    
    if ! command -v git &> /dev/null; then
        missing_prereqs+=("Git - Install with: brew install git (macOS) or sudo apt install git (Linux)")
    fi
    
    if [ ${#missing_prereqs[@]} -gt 0 ]; then
        print_error "❌ Missing prerequisites:"
        for prereq in "${missing_prereqs[@]}"; do
            print_error "   - $prereq"
        done
        echo ""
        print_error "Please install the missing prerequisites and run the script again."
        exit 1
    fi
    
    print_status "✅ Prerequisites check passed"
}

# Check if services are running
check_services() {
    print_warning "🔍 Checking if required services are running..."
    
    # Check PostgreSQL
    if ! pg_isready -h localhost -p 5432 &> /dev/null; then
        print_warning "⚠️  PostgreSQL is not running. Attempting to start..."
        
        # Try different methods to start PostgreSQL
        if command -v brew &> /dev/null; then
            # macOS with Homebrew
            brew services start postgresql@14 2>/dev/null || brew services start postgresql 2>/dev/null || true
        elif command -v systemctl &> /dev/null; then
            # Linux with systemd
            sudo systemctl start postgresql 2>/dev/null || true
        fi
        
        sleep 3
        if ! pg_isready -h localhost -p 5432 &> /dev/null; then
            print_error "❌ Could not start PostgreSQL. Please start it manually:"
            print_error "   macOS: brew services start postgresql"
            print_error "   Linux: sudo systemctl start postgresql"
            exit 1
        fi
    fi
    
    # Check Redis
    if ! redis-cli ping &> /dev/null; then
        print_warning "⚠️  Redis is not running. Attempting to start..."
        
        if command -v brew &> /dev/null; then
            # macOS with Homebrew
            brew services start redis 2>/dev/null || true
        elif command -v systemctl &> /dev/null; then
            # Linux with systemd
            sudo systemctl start redis-server 2>/dev/null || sudo systemctl start redis 2>/dev/null || true
        fi
        
        sleep 3
        if ! redis-cli ping &> /dev/null; then
            print_error "❌ Could not start Redis. Please start it manually:"
            print_error "   macOS: brew services start redis"
            print_error "   Linux: sudo systemctl start redis-server"
            exit 1
        fi
    fi
    
    print_status "✅ Services are running"
}

# Setup database
setup_database() {
    print_warning "🗄️ Setting up database..."
    
    # Check if database already exists
    if psql -h localhost -U postgres -lqt 2>/dev/null | cut -d \| -f 1 | grep -qw leave_management; then
        print_status "✅ Database already exists"
        return
    fi
    
    # Try to create database and user
    if psql -h localhost -U postgres -c "CREATE USER leave_admin WITH PASSWORD 'leave_pass';" 2>/dev/null; then
        psql -h localhost -U postgres -c "CREATE DATABASE leave_management OWNER leave_admin;" 2>/dev/null
        psql -h localhost -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE leave_management TO leave_admin;" 2>/dev/null
        print_status "✅ Database setup completed"
    else
        # Try with current user (common on macOS)
        createuser leave_admin 2>/dev/null || true
        createdb leave_management -O leave_admin 2>/dev/null || true
        psql -d leave_management -c "ALTER USER leave_admin PASSWORD 'leave_pass';" 2>/dev/null || true
        print_status "✅ Database setup completed"
    fi
}

# Clone and organize repository
setup_repository() {
    if [ ! -d "LMS" ]; then
        print_warning "📥 Cloning LMS repository..."
        git clone https://github.com/sirjoon/LMS.git
        print_status "✅ Repository cloned successfully"
    else
        print_status "✅ Repository already exists"
    fi
    
    cd LMS
    
    # Create directory structure
    print_warning "📁 Creating directory structure..."
    mkdir -p api/routers api/utils frontend/src/contexts frontend/src/components
    mkdir -p frontend/src/pages/admin frontend/src/pages/manager frontend/src/pages/employee
    mkdir -p frontend/src/services frontend/src/test
    
    # Organize API files
    print_warning "🔧 Organizing API files..."
    [ -f "api-main.py" ] && cp "api-main.py" "api/main.py"
    [ -f "api-models.py" ] && cp "api-models.py" "api/models.py"
    [ -f "api-database.py" ] && cp "api-database.py" "api/database.py"
    [ -f "api-seed.py" ] && cp "api-seed.py" "api/seed.py"
    [ -f "api-requirements.txt" ] && cp "api-requirements.txt" "api/requirements.txt"
    
    # Copy router files
    [ -f "api-routers-init.py" ] && cp "api-routers-init.py" "api/routers/__init__.py"
    [ -f "api-admin-router.py" ] && cp "api-admin-router.py" "api/routers/admin.py"
    [ -f "api-manager-router.py" ] && cp "api-manager-router.py" "api/routers/manager.py"
    [ -f "api-employee-router.py" ] && cp "api-employee-router.py" "api/routers/employee.py"
    [ -f "api-shared-router.py" ] && cp "api-shared-router.py" "api/routers/shared.py"
    [ -f "api-auth-router.txt" ] && cp "api-auth-router.txt" "api/routers/auth.py"
    
    # Copy utils files
    [ -f "api-utils-init.py" ] && cp "api-utils-init.py" "api/utils/__init__.py"
    [ -f "api-auth-utils.py" ] && cp "api-auth-utils.py" "api/utils/auth.py"
    [ -f "api-logging-config.py" ] && cp "api-logging-config.py" "api/utils/logging_config.py"
    
    # Organize frontend files
    print_warning "🎨 Organizing frontend files..."
    [ -f "frontend-package-json.json" ] && cp "frontend-package-json.json" "frontend/package.json"
    [ -f "frontend-vite-config.ts" ] && cp "frontend-vite-config.ts" "frontend/vite.config.ts"
    [ -f "frontend-tailwind-config.js" ] && cp "frontend-tailwind-config.js" "frontend/tailwind.config.js"
    [ -f "frontend-index-html.html" ] && cp "frontend-index-html.html" "frontend/index.html"
    [ -f "frontend-main-tsx.ts" ] && cp "frontend-main-tsx.ts" "frontend/src/main.tsx"
    [ -f "frontend-app-tsx.ts" ] && cp "frontend-app-tsx.ts" "frontend/src/App.tsx"
    [ -f "frontend-index-css.css" ] && cp "frontend-index-css.css" "frontend/src/index.css"
    [ -f "frontend-auth-context.ts" ] && cp "frontend-auth-context.ts" "frontend/src/contexts/AuthContext.tsx"
    [ -f "frontend-api-service.ts" ] && cp "frontend-api-service.ts" "frontend/src/services/api.ts"
    [ -f "frontend-layout.ts" ] && cp "frontend-layout.ts" "frontend/src/components/Layout.tsx"
    [ -f "frontend-loading-spinner.ts" ] && cp "frontend-loading-spinner.ts" "frontend/src/components/LoadingSpinner.tsx"
    [ -f "frontend-login-page.ts" ] && cp "frontend-login-page.ts" "frontend/src/pages/Login.tsx"
    [ -f "frontend-test-setup.ts" ] && cp "frontend-test-setup.ts" "frontend/src/test/setup.ts"
    
    # Copy page files
    [ -f "frontend-admin-users.ts" ] && cp "frontend-admin-users.ts" "frontend/src/pages/admin/Users.tsx"
    [ -f "frontend-admin-leave-types.ts" ] && cp "frontend-admin-leave-types.ts" "frontend/src/pages/admin/LeaveTypes.tsx"
    [ -f "frontend-admin-holidays.ts" ] && cp "frontend-admin-holidays.ts" "frontend/src/pages/admin/Holidays.tsx"
    [ -f "frontend-manager-pending.ts" ] && cp "frontend-manager-pending.ts" "frontend/src/pages/manager/PendingRequests.tsx"
    [ -f "frontend-manager-history.ts" ] && cp "frontend-manager-history.ts" "frontend/src/pages/manager/RequestHistory.tsx"
    [ -f "frontend-employee-balance.ts" ] && cp "frontend-employee-balance.ts" "frontend/src/pages/employee/LeaveBalance.tsx"
    [ -f "frontend-employee-apply.ts" ] && cp "frontend-employee-apply.ts" "frontend/src/pages/employee/ApplyLeave.tsx"
    [ -f "frontend-employee-requests.ts" ] && cp "frontend-employee-requests.ts" "frontend/src/pages/employee/RequestHistory.tsx"
    
    # Fix database.py import issue
    print_warning "🔧 Fixing database import issue..."
    cat > api/database.py << 'EOF'
from sqlalchemy import create_engine, pool
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
import redis.asyncio as redis
import os
import structlog

Base = declarative_base()

logger = structlog.get_logger()

# Database configuration
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql+psycopg://leave_admin:leave_pass@localhost:5432/leave_management")
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")

# Create engine with connection pooling
engine = create_engine(
    DATABASE_URL,
    poolclass=pool.QueuePool,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
    pool_recycle=3600,
    echo=os.getenv("SQL_DEBUG", "false").lower() == "true"
)

# Create session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Redis client
redis_client = None

async def get_redis():
    """Get Redis client instance"""
    global redis_client
    if redis_client is None:
        redis_client = redis.from_url(REDIS_URL, decode_responses=True)
    return redis_client

def get_db():
    """Database dependency for FastAPI"""
    db = SessionLocal()
    try:
        yield db
    except Exception as e:
        logger.error("Database session error", error=str(e))
        db.rollback()
        raise
    finally:
        db.close()

async def get_db_async():
    """Async database dependency"""
    db = SessionLocal()
    try:
        yield db
    except Exception as e:
        logger.error("Async database session error", error=str(e))
        db.rollback()
        raise
    finally:
        db.close()
EOF
    
    print_status "✅ Files organized successfully"
}

# Setup backend
setup_backend() {
    print_warning "🐍 Setting up Python backend..."
    cd api
    
    # Create virtual environment
    python3 -m venv venv
    source venv/bin/activate
    
    # Install dependencies
    pip install -r requirements.txt
    
    # Set environment variables
    export DATABASE_URL="postgresql+psycopg://leave_admin:leave_pass@localhost:5432/leave_management"
    export REDIS_URL="redis://localhost:6379/0"
    export JWT_SECRET="supersecret_change_in_production"
    export SEED_DEMO="true"
    export LOG_LEVEL="INFO"
    export ENVIRONMENT="development"
    
    print_status "✅ Backend setup completed"
}

# Setup frontend
setup_frontend() {
    print_warning "⚛️ Setting up React frontend..."
    cd ../frontend
    
    # Install dependencies
    npm install
    
    print_status "✅ Frontend setup completed"
}

# Start services
start_services() {
    print_warning "🚀 Starting services..."
    
    # Start API server in background
    cd ../api
    source venv/bin/activate
    export DATABASE_URL="postgresql+psycopg://leave_admin:leave_pass@localhost:5432/leave_management"
    export REDIS_URL="redis://localhost:6379/0"
    export JWT_SECRET="supersecret_change_in_production"
    export SEED_DEMO="true"
    export LOG_LEVEL="INFO"
    export ENVIRONMENT="development"
    
    print_info "Starting API server at http://localhost:8000..."
    nohup uvicorn main:app --host 0.0.0.0 --port 8000 --reload > ../api.log 2>&1 &
    API_PID=$!
    echo $API_PID > ../api.pid
    
    # Start frontend server in background
    cd ../frontend
    print_info "Starting frontend server at http://localhost:5173..."
    nohup npm run dev > ../frontend.log 2>&1 &
    FRONTEND_PID=$!
    echo $FRONTEND_PID > ../frontend.pid
    
    # Wait for services to start
    sleep 10
    
    print_status "✅ Services started successfully"
}

# Test services
test_services() {
    print_warning "🧪 Testing services..."
    
    # Test API
    for i in {1..10}; do
        if curl -s http://localhost:8000/health > /dev/null 2>&1; then
            print_status "✅ API is responding correctly!"
            break
        else
            print_warning "⏳ Waiting for API to start... (attempt $i/10)"
            sleep 3
        fi
    done
    
    # Test if frontend is accessible (just check if port is open)
    if nc -z localhost 5173 2>/dev/null; then
        print_status "✅ Frontend server is running!"
    else
        print_warning "⚠️  Frontend might still be starting..."
    fi
}

# Cleanup function
cleanup() {
    echo ""
    print_warning "🛑 Stopping services..."
    
    if [ -f "api.pid" ]; then
        kill $(cat api.pid) 2>/dev/null || true
        rm -f api.pid
    fi
    
    if [ -f "frontend.pid" ]; then
        kill $(cat frontend.pid) 2>/dev/null || true
        rm -f frontend.pid
    fi
    
    print_status "✅ Services stopped"
    exit 0
}

# Set up signal handlers
trap cleanup SIGINT SIGTERM

# Main execution
main() {
    check_prerequisites
    check_services
    setup_database
    setup_repository
    setup_backend
    setup_frontend
    start_services
    test_services
    
    # Final status
    echo ""
    print_status "🎉 LMS Setup Complete!"
    print_status "======================"
    echo ""
    print_info "📱 Frontend:      http://localhost:5173"
    print_info "🔧 API:           http://localhost:8000"
    print_info "📚 API Docs:      http://localhost:8000/docs"
    print_info "🏥 Health Check:  http://localhost:8000/health"
    echo ""
    print_warning "👥 Demo Users:"
    echo "   Admin:    admin / admin123"
    echo "   Manager:  manager / manager123"
    echo "   Employee: alice / alice123"
    echo ""
    print_warning "📋 Logs:"
    echo "   API: tail -f api.log"
    echo "   Frontend: tail -f frontend.log"
    echo ""
    print_warning "🛑 To stop the servers:"
    echo "   Press Ctrl+C in this terminal"
    echo ""
    
    # Ask to open browser
    read -p "Would you like to open the LMS in your default browser? (y/N): " open_browser
    if [[ $open_browser =~ ^[Yy]$ ]]; then
        if command -v open &> /dev/null; then
            # macOS
            open http://localhost:5173
        elif command -v xdg-open &> /dev/null; then
            # Linux
            xdg-open http://localhost:5173
        else
            print_info "Please open http://localhost:5173 in your browser"
        fi
    fi
    
    print_warning "Press Ctrl+C to stop the servers when you're done testing."
    
    # Wait indefinitely until interrupted
    while true; do
        sleep 1
    done
}

# Run main function
main

